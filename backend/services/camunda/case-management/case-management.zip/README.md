## Case Management

In Australia there are guidelines, policies, and standards developed by different government agencies and organisations 
to guide practitioners in providing coordinated, client-centred support and care across various sectors, such as 
child protection, health, and family violence. 

These frameworks typically include phases like screening, assessment, planning, and evaluation, emphasising multi-agency 
collaboration, risk assessment, and culturally responsive practices to ensure the safety and well-being of clients 
within their broader social context.

Case management typically include six core elements:
- Client identification and eligibility determination
- Client Assessment
- Care planning and goal setting
- Plan implementation
- Plan monitoring
- Transition and discharge

### Client Identification and Eligibility Determination
Case finding describes a process involving activities focused upon the identification of patients/clients not currently 
receiving case management services. Establishing rapport consists of building an interpersonal connection between the 
case manager and the patient/client.

### Client Assessment
Assessment refers to construct a detailed, comprehensive understanding of the patient/client which includes, their 
healthcare and social needs, their capabilities, and the resources they have access to in their family and community.

### Care Planning and Goal Setting
Planning encompasses the steps necessary to build a care plan that defines treatment goals, tasks and actions needed to 
move towards those goals, access to specific services and supports required to achieve the stated goals and final the 
identification of targeted outcomes that are specific to that the patient/client. 
Navigation encompasses the part of the case management process where the case manager helps guide the patient/client to 
services and supports recognizing and working to remove barriers that can either be anticipated or those that 
unexpectedly arise. Provision of care occurs when the case manager is also part of the treatment team as might happen 
in the mental health setting. For example, where the patient' s/client's case manager might also be part of the therapy 
team providing counseling and skills training.

### Plan Implementation
Implementation, is the part of the case management program where the plan of care with its varied activities and tasks, 
is set in motion. Coordination is related to navigation but is broader and refers to the myriad of facilitations that 
must occur between and among care providers, service settings, organizations, and institutions with the patient/client 
also being the focus and at the center of this component of the case management process.

### Plan Monitoring
Monitoring occurs throughout the entire process and is related to seeking ongoing feedback and conducting follow-up as 
necessary to how the plan of care is being implemented and producing results. Evaluation is closely related to 
monitoring but occurs at specific milestones during the case management process to formally determine if the care plan 
helps the patient/client achieve progress towards goals and outcomes. Feedback as a component of case management 
involves communication back to service providers about their services' effectiveness. It supports in assisting the 
patient/client in making progress as defined in the plan of care. Providing education and information encompasses 
helping the patient/client and their family/support system develop a deeper understanding of relevant health and health 
care topics. Advocacy refers to activities directed at empowering the patient/client to pursue services and supports 
and related accommodations and proper entitlements to their circumstances. Supportive counseling describes the case 
manager's effort to consistently provide encouragement and emotional support as the care plan unfolds. 
Administration encompasses the paperwork, report writing, and data gathering and analysis that are part and parcel of 
the modern health care system.

### Transition and Discharge
Transition describes the process when a client is prepared to move across the healthcare continuum, depending on the 
patient's health and the need for services. The client can be moved home or transferred to another facility for 
further care. Discharge represents the case management process component in which the patient's/client's case reaches 
the point of closure, goals are met, and the patient's needs warrant disengagement with the case management process. 

Finally, community service development occurs when the case management process uncovers a need or service gap within a 
given community. Then the case manager catalyzes efforts to create that service or support to fill that gap.
